
function validateForm() {
	
	"use strict";
	var n = document.eduform.Name.value;
	var e = document.eduform.email.value;
    var p = document.eduform.Password.value;
	var cp = document.eduform.CPassword.value;
	var con =  document.eduform.contact.value;
	var l=p.length;
	
	if(n==="")
		{
			alert("Name is empty");
			return false;
		}
	
	if(e === "")
		{
			alert("Email-Id is empty");
			return false;
		}
	if(p === "")
		{
			alert("Password is empty");
			return false;
		}
	
	if (p !== cp)
		{
			alert("password not matched");
			return false;
		}
	
		
	
		if(l<6 || l >12)
			{
				alert(" Password must be minimum 6 digit and maximum 12 digit ");
				return false;
			}
			
	if (con === "" || con < 10 || con > 10)
		{
			alert("Please give valid contact number ex:-80839662XX");
			return false;
		}
	
}// JavaScript Document